//  Celda.swift
//  Coleccion
/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 11 - Coleccion de numeros - 20/04/2021
Versión 1.0
*/

import UIKit

class Celda: UICollectionViewCell {
    @IBOutlet weak var imagenNum: UIImageView!
}
