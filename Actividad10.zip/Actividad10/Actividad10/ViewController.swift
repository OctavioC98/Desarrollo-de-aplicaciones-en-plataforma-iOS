//
//  ViewController.swift
//  Actividad10
//
//  Created by user182925 on 4/12/21.
//  Copyright © 2021 Tecmilenio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

