/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 6 - Operadores personalizados, subscript y control de errores - 08/03/2021
Resolver los planteamientos para los temas operadores personalizados, subscript y control de errores.
Versión 1.0
*/
import UIKit

// Crea el operador para realizar la potencia del valor a a la potencia b en valores enteros.

infix operator ***

func *** (valora:Int, valorb:Int) -> Double
{
    let base = Double (valora)
    let potencia = Double (valorb)

    return pow(base, potencia)
}

print("La potencia es: ")
print(2***4);

// Crea el operador |> para ordenar la colección [2,5,3,4] de menor a mayor.

var coleccion1 = [2,5,3,4]
prefix operator |>

prefix func |>(coleccion:Array<Int>) -> Array<Int>
{
    return coleccion.sorted()
}

|>coleccion1

// Del conjunto de datos en el Array [2,3,4,5], crea el subscript para modificar los valores multiplicados por el valor 2 y extrae al valor dado un índice.

class ModificadorValor
{
    var valores:[Int]
    init(v:[Int])
    {
        self.valores = v
    }

    subscript(index:Int) -> Int
    {
        get
        {
            return valores[index]
        }

            set(newValue)
            {
                valores[index] = valores[index] * newValue
            }
    }
}

let valor1 = ModificadorValor(v: coleccion1)

valor1[3]
valor1[2] = 3
coleccion1

// Crear el Struct para definir u obtener la posición para los personajes de tipo Enemigo donde cada posición es de tipo CGPoint aplicando subscritps.

let Enemigo = [CGPoint(x: 1, y: 2),CGPoint(x: 3, y: 4),CGPoint(x: 5, y: 6)]

struct PosicionEnemigo
{
    var CoordenadaX:CGPoint
    var CoordenadaY:CGPoint
    var lugar:(CGPoint, CGPoint)
    
    func posicion() -> (CGPoint, CGPoint)
    {
        let lugar = (self.CoordenadaX, self.CoordenadaY)
        return lugar
    }
        subscript (idx:CGPoint) -> (CGPoint, CGPoint)
        {
            get
            {
                return lugar
            }

                set(nuevoLugar)
                {
                    lugar = nuevoLugar
                }
        }
}

// Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de una colección ["A":1, "B":2,"C":3]

var coleccion2 = ["A":1, "B":2,"C":3]

func ExisteValor (ValorABuscar:String)
{
    guard let check = coleccion2[ValorABuscar]
    
    else
    {
        print ("\nNo existe")
        return
    }

    print("\nExiste \(check)")

}

ExisteValor(ValorABuscar: "A")
coleccion2 ["D"]
