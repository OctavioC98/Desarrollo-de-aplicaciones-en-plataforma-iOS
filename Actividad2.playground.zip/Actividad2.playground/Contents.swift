/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 2 - Swift con Playground - 08/02/2021
Aprendiendo a usar la interfaz de Xcode con swift en playground
Versión 1.0
*/

import UIKit

var str = "Hello, playground"
