/* Octavio Cuellar Almazan 2874558 ICA
 Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
 Actividad 1 - Lenguaje de programación moderno - 03/02/2021
 Aplicación de "Hola mundo!"
 Versión 1.0
 */

import UIKit

//:Asignación de valor mutable
var v1 = "esto es Swift"
 
 //:Asignación de valor entero a variable constante
let c1 = 4
//: Asignación formal (definiendo el tipo de dato) a tipo cadena/string
var cadena:String = String()

cadena = "Hola mundo " + v1
print("El contenido es: \(cadena)")
print("El valor de constente es: \(c1)") //: Mostramos los diferentes mensajes/impresiones de nuestras variables.
