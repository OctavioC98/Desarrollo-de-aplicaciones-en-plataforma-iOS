/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 4 - Solucion de problemas con patrones - 22/02/2021
Aplicar los patrones vistos en el tema en un ejemplo
Versión 1.0
*/
import UIKit

// Declarar la variable "datos" con los valores [3,6,9,2,4,1]
var datos = [3,6,9,2,4,1]

// Realizar el recorrido de la variable "datos" con la instrucción "for"
print ("Recorrido de numeros")
for i in datos {
    print (i)
}

// Encontrar los valores menores a 5
print ("\nValores menores a 5 ")
for i in datos {
    if i < 5 {
        print (i)
    }
}

// Crear la función "suma" que reciba dos parámetros de tipo entero regresando la suma de ambos números.
func Suma (num1:Int, num2:Int) -> Int{
    return num1 + num2
}
Suma (num1: 1, num2: 1)

// Crear la función "potencia" que reciba dos parámetros de tipo entero, el primer parámetro para el numero base y el segundo la potencia a elevar, regresando el resultado de la potencia.
func potencia (num1:Int, num2:Int) -> Int{
    var resultado = 1
    for _ in 0...num2{
        resultado = resultado * num1
    }
    return resultado
}
potencia (num1: 2, num2: 2)

// Crea la enumaración "meses" para definir tipos de datos basados en los meses del año.
enum meses {
    case Enero
    case Febrero
    case Marzo
    case Abril
    case Mayo
    case Junio
    case Julio
    case Agosto
    case Septiembre
    case Octubre
    case Noviembre
    case Diciembre
}

// Crear la función "numeroMes" que reciba el tipo de dato "meses" y regrese el numero del mes correspondiente
func numeroMes (mes:meses)->Int{
    var nMes = 0
    	
    // Para regresar el numero de mes correspondiente utilizar la "switch"
    switch mes{
        case .Enero: nMes = 1
        case .Febrero: nMes = 2
        case .Marzo: nMes = 3
        case .Abril: nMes = 4
        case .Mayo: nMes = 5
        case .Junio: nMes = 6
        case .Julio: nMes = 7
        case .Agosto: nMes = 8
        case .Septiembre: nMes = 9
        case .Octubre: nMes = 10
        case .Noviembre: nMes = 11
        case .Diciembre: nMes = 12
    }
    return nMes
}






