//  GameViewController.swift
//  Juego2
/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 14 - Experimentando con SpriteKit - 11/05/2021
Versión 1.0
*/

import UIKit
import SpriteKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
         let ancho =  750
         let alto = 1334
        
         let scene = GameScene(size: CGSize(width: ancho, height: alto))
                        
            let skView = self.view as! SKView
            skView.showsFPS = true // Muestra los cuadros por segundo en pantalla
            skView.showsNodeCount = true
            skView.ignoresSiblingOrder = true
            scene.scaleMode = .aspectFill // Rellena la pantalla
            skView.presentScene(scene)
      
     }
}
// Fin
