/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 7 - Generics - 16/03/2021
Desarrollar en el participante la habilidad para aplicar conceptos de lógica computacional en Swift, en función de los conceptos estudiados en el tema.
Versión 1.0
*/
import UIKit

// Para la colección var costo_referencia:[Float] = [8.3,10.5,9.9], aplica el impuesto del 16% a través de recorrer la colección costo_referencia para aplicar el impuesto a cada cantidad.
// Crea una función impuesto que reciba como parámetro la colección y regrese aplicado el impuesto a cada cantidad.

var costo_referencia:[Float] = [8.3,10.5,9.9]

func Impuesto(costo:[Float]) -> [Float]
{
    var resultado:[Float] = []
    for i in costo
    {
        resultado.append((i*0.16)+i)
    }
    return resultado
}

Impuesto(costo: costo_referencia)

// Crea la función sumaTres que reciba una función con dos valores a sumar y un segundo parámetro para sumar el tercer número.

let sumaDos = {(x:Int, y:Int) -> Int in return x + y}
func sumaTres(Numero1:Int, Numero2:Int, Numero3:Int) -> Int
    {
        return sumaDos(Numero1, Numero2) + Numero3
    }

sumaTres(Numero1: 1, Numero2: 2, Numero3: 3)

// Para funciones personalizadas y genéricos, desarrolla los siguientes planteamientos:
// Crea una función genérica para intercambiar valores entre dos variables del mismo tipo.

func GenericExchange(Valor1:Int, Valor2:Int) -> (Int, Int)
{
    let Temporal = Valor1
    let Valor1_1 = Valor2
    let Valor2_1 = Temporal
    return(Valor1_1, Valor2_1)
}

GenericExchange(Valor1:1, Valor2:2)

// Crea la función Transformar que reciba como parámetro una colección de tipo Int var datos = [3,7,9,2] y una función que transforme cada valor de la colección en una operación definida fuera de la función, regresando una colección transformada.

let sumaTransformar = {(a:Int,b:Int)-> Int in return a + b}
extension Array
{
    func Transformar(arreglo:[Int],x:Int)->[Int]
    {
        var resultado:[Int]=[];

        for valor in 0...arreglo.count-1
        {
            resultado.append(sumaTransformar(arreglo[valor],x))
        }

        return resultado

    }
}

var datos = [3,7,9,2]
datos
datos.Transformar(arreglo:datos,x:2)

// Aplica la función de librería de Swift map para la colección var precios = [4.2, 5.3, 8.2, 4.5] y aplica el impuesto de 16% y asígnala a la variable impuesto.

var precios = [4.2, 5.3, 8.2, 4.5]
var impuesto = precios.map{i in return ((i*0.16)+i)}
impuesto

// Aplica la función de la librería de Swift filter para la colección resultante impuesto del paso A, en donde obtengas sólo los precios mayores a 6.0 y asígnalos a la variable precio_menor.

var precio_menor = impuesto.filter{i in i>6.0}
precio_menor

// Fin de la actividad.

