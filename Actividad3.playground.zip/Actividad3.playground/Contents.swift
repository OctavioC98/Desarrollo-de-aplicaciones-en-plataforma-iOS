/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 3 - Solucion de problemas aplicando fundamentos Swift - 15/02/2021
Desarrollar la logica computacional a traves de Swift
Versión 1.0
*/
import UIKit

// Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida

var NumeroEntero :Int = 10
NumeroEntero = 10

var NumeroDecimal :Float = 7.5
NumeroDecimal = 7.5

var Cadena1 :String = ("Hola")
Cadena1 = "Hola"

var Cadena2 = "Hola mundo!"

// Declarar el tipo de dato por asociación para un tipo de dato String
Cadena1 = "Hola"

// Declarar el tipo de dato por asociación para un tipo de dato  Número entero.
NumeroEntero = 10

// Crear la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
var numeros:Array<Int> = Array<Int>()
numeros.append(1)
numeros.append(2)
numeros.append(3)
numeros.append(4)
numeros.append(5)
numeros.append(6)
numeros.append(7)
numeros.append(8)
numeros.append(9)
numeros.append(10)

// Crear la variable "diasSemana" de tipo Dictionary con la relación numero:día Ej. 1:"Lunes"
var diasSemana:Dictionary<String, Int> = Dictionary<String, Int>()
diasSemana = ["Lunes":1]
diasSemana = ["Martes":2]
diasSemana = ["Miércoles":3]
diasSemana = ["Jueves":4]
diasSemana = ["Viernes":5]
diasSemana = ["Sábado":6]
diasSemana = ["Domingo":7]



