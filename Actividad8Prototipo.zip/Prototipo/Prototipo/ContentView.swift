/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 8 - Prototipado - 23/03/2021
Prototipo
Versión 1.0
*/

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hola mundo!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
