/* Octavio Cuellar Almazan 2874558 ICA
Desarrollo de aplicaciones en plataforma iOS - Miguel Pérez Maciel
Actividad 5 - Más fundamentos - 01/03/2021
Desarrollar habilidad para desarrollar la lógica computacional a través de Swift.
Versión 1.0
*/
import UIKit

// Diseña la clase Persona que contenga dos métodos:
// a.    El primero "Saludar", que reciba el parámetro nombre y regrese el mensaje, el nombre más el texto "mucho gusto".
// b.    El segundo método "Caminar", que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el número de pasos caminados.

class Persona
{
    var Saludar:String
    var Caminar:Int
    
    init(Saludar:String, Caminar:Int)
    {
        self.Saludar = Saludar
        self.Caminar = Caminar
    }
    
    func Saludo(Saludar:String)
    {
        print("\(Saludar) mucho gusto")
    }
    
    func pasos(Caminar:Int)
    {
        print("\(Caminar) pasos caminados")
    }
}

// Para el tema Struct, diseña el struct Pantalla, la cual recibirá como parámetros el ancho y alto de una pantalla como tipo de datos Int con un constructor para inicializar la estructura.

struct Pantalla
{
    var alto: Int
    var ancho: Int
    
    init(alto:Int, ancho:Int)
    {
        self.alto = alto
        self.ancho = ancho
    }
    
    func Tamaño() -> (Int,Int)
    {
        return (self.alto, self.ancho)
    }
}

var TamañoPantalla = Pantalla(alto: 1920, ancho: 1080)
TamañoPantalla.Tamaño()

// Para el tema extensión, diseña un extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada)
// Y diseña una extensión del tipo de dato String que represente un día de la semana y regrese el número correspondiente iniciando con Domingo = 1 y finalizando con Sábado = 7.

extension Int
{
    var horas:Int
    {
        return self*3600
    }
}

extension String
{
    var dia:String{
        return self
    }
    
    func numero() -> String
    {
        switch self.dia
        {
        case "Domingo":
            return "1"
        case "Lunes":
            return "2"
        case "Martes":
            return "3"
        case "Miercoles":
            return "4"
        case "Jueves":
            return "5"
        case "Viernes":
            return "6"
        case "Sabado":
            return "7"
        default:
            return "No se reconoció el dia"
        }
    }
}

// Para el tema Optional, diseña una variable optional para recibir el tipo de dato Int en caso de que exista.

var Optional:Int

// Para la colección - let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200], diseña una variable opcional para recibir el valor de dias["DF"].

let dias = ["GLD":120, "PUE":300, "MTY":100, "CDMX":200]
var existe:Int?

existe = dias["CDMX"]
existe = dias["DF"]

if dias["DF"] != nil
{
    print("Si existe")
}
    else
    {
    print("No existe")
    }
